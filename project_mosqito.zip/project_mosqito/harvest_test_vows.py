import os
import parselmouth
from parselmouth import praat
import file_input
import math

# Function to analyze a single audio file
def analyze_audio(file, output_file):
    filename_ext=os.path.basename(file)
    filename=os.path.splitext(filename_ext)[0]
    print(f"Filename:{filename}")

    sound = parselmouth.Sound(file) 
    f0min = 75
    f0max = 3150
    pointProcess = praat.call(sound, "To PointProcess (periodic, cc)", f0min, f0max)
    
    formants = praat.call(sound, "To Formant (burg)", 0.0025, 5, 5000, 0.025, 50)
    
    numPoints = praat.call(pointProcess, "Get number of points")
    f1_list = []
    f2_list = []
    f3_list = []
    for point in range(0, numPoints):
        point += 1
        t = praat.call(pointProcess, "Get time from index", point)
        f1 = praat.call(formants, "Get value at time", 1, t, 'Hertz', 'Linear')
        f2 = praat.call(formants, "Get value at time", 2, t, 'Hertz', 'Linear')
        f3 = praat.call(formants, "Get value at time", 3, t, 'Hertz', 'Linear')
        if not math.isnan(f1):
            f1_list.append(f1)
        if not math.isnan(f2):
            f2_list.append(f2)
        if not math.isnan(f1):
            f3_list.append(f3)


        # f1_list.append(f1)

        # f2_list.append(f2)

        # f3_list.append(f3)
    try:
        f1_ave = sum(f1_list) / len(f1_list)
        print(f"F1:{f1_ave}")
    except ZeroDivisionError:
        f1_ave=0
    
    try:
        f2_ave = sum(f2_list) / len(f2_list)
        print(f"F2:{f2_ave}\n")
    except ZeroDivisionError:
        f2_ave=0

    try:
        f3_ave= sum(f3_list) / len(f3_list)
        print(f"F2:{f3_ave}\n")
    except ZeroDivisionError:
        f3_ave=0

    
    #append to file
    with open (output_file,'a') as output:
        output.write(f'{1},Vowel,*,{filename},{f1_ave},{f2_ave},{f3_ave}\n')
        output.flush()

# Specify the directory containing the audio files
input_directory = "res/training_data/wikipedia/vows"
output_file="memory/sample_weights_vows.txt"
#clear file
with open(output_file,'w')as output:
    output.write('')

# List all files in the input directory
for root, _, files in os.walk(input_directory):
    for file in files:
        if file.lower().endswith((".wav", ".mp3", ".ogg")):
            file_path = os.path.join(root, file)
            analyze_audio(file_path,output_file)
