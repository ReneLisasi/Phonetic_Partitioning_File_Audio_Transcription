class TreeNode:
    #constructor
    def __init__(self, data):
        self.data=data
        self.children=[]

    def addChild(self,child_node):
        self.children.append(child_node)

    def print_tree(self, level=0):
        print("\t" * level + str(self.data))
        for child in self.children:
            child.print_tree(level + 1)

    def set_children_attr(self, value, attr):
        for child in self.children:
            current_cost = getattr(child.data, attr)  # Get the current cost attribute
            setattr(child.data, 'cost', abs(float(current_cost) - value))

    def get_children_data(self):
        return [child.data for child in self.children]

#addNode
    def addNode(self, child):
        child.parent=self
        self.children.append(child)
    #print tree
    def print_tree_node(self):
        print(self.data.name)

class Tree:
    def __init__(self, root):
        self.root = TreeNode(root)

    #insert method
    def insert(node,key):
        #if the tree is empty return a new node
        if node is None:
            return TreeNode(key)

#sound object
class Speech:
    def __init__(self,type,type_name,parent,name,f1,f2,f3):
        self.type=type
        self.type_name=type_name
        self.parent=parent
        self.name=name
        self.f1=f1
        self.f2=f2
        self.f3=f3
        self.cost=0
    
    def __lt__(self, other):
        return self.cost<other.cost

    def print_speech(self):
        return self.type,self.type_name,self.parent,self.name,self.f1,self.f2,self.f3
    
    def set_speech_cost(self,cost):
        self.cost=cost

class Vowel(Speech):
    def __init__(self,parent, name, f1, f2,f3):
        super().__init__(type,type_name,parent,name,f1,f2,f3)
        self.type=1
        self.type_name='Vowel'

class SubVowel(Speech):
    def __init__(self,parent, name, f1, f2,f3):
        super().__init__(type,type_name,parent,name,f1,f2,f3)
        self.type=2
        self.type_name='Subvowel'

class Consonant(Speech):
    def __init__(self,parent, name, f1, f2,f3):
        super().__init__(type,type_name,parent,name,f1,f2,f3)
        self.type=3
        self.type_name='Consonant'

class SubConsonant(Speech):
    def __init__(self,parent, name, f1, f2,f3):
        super().__init__(type,type_name,parent,name,f1,f2,f3)
        self.type=4
        self.type_name='Subconsonant'

tree=Tree('*')
root=tree.root

def get_node_position(value):
    node = node_mapping[value]
    return node


def set_node_positions():
    node_mapping[name] = parent_node

import csv
node_mapping={}
#final csv:::
with open('memory/sounds.csv', newline='') as csvfile:
    reader = csv.reader(csvfile)

    for row in reader:
        type, type_name, parent, name, f1, f2, f3 = row
        try:
            type = int(type)
            f1 = float(f1)
            f2 = float(f2)
            f3 = float(f3)

            if type == 1:
                parent_node = TreeNode(Vowel(parent, name, f1, f2, f3))
                root.addChild(parent_node)
                node_mapping[name] = parent_node
            elif type == 3:
                parent_node = TreeNode(Consonant(parent, name, f1, f2, f3))
                root.addChild(parent_node)
                node_mapping[name] = parent_node
            elif type == 2 and parent in node_mapping:
                parent_node = node_mapping[parent]
                child = TreeNode(SubVowel(parent, name, f1, f2, f3))
                parent_node.addChild(child)
            elif type == 4 and parent in node_mapping:
                parent_node = node_mapping[parent]
                child = TreeNode(SubConsonant(parent, name, f1, f2, f3))
                parent_node.addChild(child)
        except (ValueError, IndexError):
            # Skip lines that don't contain numeric values or are too short
            pass

        
# root.print_tree()