import binary_search_tree
from harvest import harvest_data
import file_input
from linear_algebra import cosine_similarity
import heapq

def compare_sound(input_letter,seed_vector,harvest_root):
    #1/2 depths
    stem=harvest_root.get_children_data()
    leaf=[]
    for branch in stem:
        petiole=[branch.f1,branch.f2,branch.f3]
        vein=cosine_similarity(seed_vector,petiole)
        branch.set_speech_cost(vein)
        # # # sort as we go
        # heapq.heappush(leaf, (branch.cost, branch))
        # #remove the other branch if it is bigger, to save memory
        # if len(leaf)>1:
        #     heapq.heappop(leaf)
        leaf.append((branch))
    leaf=sorted(leaf,key=lambda x:x.cost)
    fruit = leaf[0]
    # print(f'Most similar sound 1/2: {fruit[1].print_speech()} distance: {fruit[0]}, vein: {vein}')
    print(f'Most similar sound 1/2: {fruit.print_speech()} distance: {fruit.cost}, vein: {vein}')

    #2/2 depths
    new_root=binary_search_tree.node_mapping[fruit.name]
    stem=new_root.get_children_data()
    leaf=[]
    for branch in stem:
        petiole=[branch.f1,branch.f2,branch.f3]
        vein=cosine_similarity(seed_vector,petiole)
        branch.set_speech_cost(vein)
        # # sort as we go
        # heapq.heappush(leaf, (vein, branch))
        # #remove the other branch if it is bigger, to save memory
        # if len(leaf)>1:
        #     heapq.heappop(leaf)
        leaf.append((branch))
    leaf=sorted(leaf,key=lambda x:x.cost)
    new_fruit=leaf[0]
    # Now, leaf_sorted contains tuples sorted based on the vein value
    # print(f'Most similar sound 2/2: {new_fruit[1].print_speech()}, distance: {new_fruit[0]}, vein: {vein}')
    print(f'Most similar sound 2/2: {new_fruit.print_speech()}, distance: {new_fruit.cost}, vein: {vein}')
    return new_fruit

# def listen(path):
#     seed_vector=harvest_data(path)
#     input_letter=binary_search_tree.Speech(0,'unknown_type','unknown_parent','',seed_vector[0],seed_vector[1],seed_vector[2])
#     test_root=binary_search_tree.root
#     final_fruit=compare_sound(input_letter,seed_vector,test_root)
#     print(f'{final_fruit[1].name}')

def listen(path):
    seed_vector=harvest_data(path)
    if seed_vector[0]!=0:
        input_letter=binary_search_tree.Speech(0,'unknown_type','unknown_parent','',seed_vector[0],seed_vector[1],seed_vector[2])
        test_root=binary_search_tree.root
        final_fruit=compare_sound(input_letter,seed_vector,test_root)
        # print(f'{final_fruit.name}')
        return final_fruit.name

# listen(file_input.rel_path)
# #example code
# seed_vector=harvest.harvest_data(file_input.rel_path)
# input_letter=binary_search_tree.Speech(0,'unknown_type','unknown_parent','unknown_name',seed_vector[0],seed_vector[1],seed_vector[2])
# test_root=binary_search_tree.root
# new_fruit=compare_sound(seed_vector,test_root)
# new_branch=binary_search_tree.node_mapping[new_fruit[1].name]
# final_fruit=compare_sound(seed_vector,new_branch)
