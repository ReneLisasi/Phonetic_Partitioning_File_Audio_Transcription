import os
import tempfile
from pydub import AudioSegment
import compare3
import harvest

def create_and_save_slices(output,input_path, slice_duration_ms, output_format="wav"):
    audio = AudioSegment.from_wav(input_path)

    slice_duration = slice_duration_ms  # milliseconds
    start_time = 0
    end_time = slice_duration

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    try:
        while end_time <= len(audio):
            # Create a slice
            slice_segment = audio[start_time:end_time]

            # Save the slice in the temporary directory
            slice_filename = f"input_slice_{start_time}-{end_time}.{output_format}"
            slice_filepath = os.path.join(temp_dir, slice_filename)
            slice_segment.export(slice_filepath, format=output_format)

            # Clear the slice from memory
            del slice_segment

            # Move on to the next slice
            start_time += slice_duration
            end_time += slice_duration

    finally:
        # Clear the temporary directory and its contents
        for temp_file in os.listdir(temp_dir):
            temp_file_path = os.path.join(temp_dir, temp_file)
            # print(temp_file_path)
            temp_output = compare3.listen(temp_file_path)
            if temp_output is not None:
                output+=temp_output
            # harvest.harvest_data(temp_file_path)
            os.remove(temp_file_path)
        os.rmdir(temp_dir)
    return output
        


if __name__ == "__main__":
    input_wav_path = "res/test_data/words/shame2t.wav"
    slice_interval=30#in ms
    output=''
    final_output=create_and_save_slices(output,input_wav_path,slice_interval)
    print(final_output)


# from textblob import TextBlob
 
# a = output           # incorrect spelling
# print("original text: "+str(a))
 
# b = TextBlob(a)
 
# # prints the corrected spelling
# print("corrected text: "+str(b.correct()))