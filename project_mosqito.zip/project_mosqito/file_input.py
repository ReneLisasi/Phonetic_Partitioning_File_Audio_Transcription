#Encapsulation of input cycle, output path, label
import os

rel_path = 'res/training_data/wikipedia/vows/e.wav'

# Use os.path.splitext to split the file name and extension, and then take the file name part
voice_filename = os.path.splitext(os.path.basename(rel_path))[0]

# print(voice_filename)