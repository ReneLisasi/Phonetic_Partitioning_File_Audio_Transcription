import parselmouth
from parselmouth import praat
import file_input

rel_path=file_input.rel_path
voice_filename=file_input.voice_filename

# Print the file name without the extension
print(f"------\nBegin harvest for ~ {voice_filename}\n------")

sound = parselmouth.Sound(rel_path) 
f0min=75
f0max=3000
pointProcess = praat.call(sound, "To PointProcess (periodic, cc)", f0min, f0max)

formants = praat.call(sound, "To Formant (burg)", 0.0025, 5, 5000, 0.025, 50)


numPoints = praat.call(pointProcess, "Get number of points")
f1_list = []
f2_list = []
f3_list = []
for point in range(0, numPoints):
    point += 1
    t = praat.call(pointProcess, "Get time from index", point)
    f1 = praat.call(formants, "Get value at time", 1, t, 'Hertz', 'Linear')
    f2 = praat.call(formants, "Get value at time", 2, t, 'Hertz', 'Linear')
    f3 = praat.call(formants, "Get value at time", 3, t, 'Hertz', 'Linear')
    f1_list.append(f1)
    f2_list.append(f2)
    f3_list.append(f3)

print(f"F1:{f1_list}")
print(f"F2:{f2_list}")
print(f"F3:{f3_list}")
try:
    f1_ave=sum(f1_list)/len(f1_list)
    print(f"F1 average:{f1_ave}")
except ZeroDivisionError:
    f1_ave=0
    print(f"F1 average:{f1_ave}")
try:
    f2_ave=sum(f2_list)/len(f2_list)
    print(f"F2 average:{f2_ave}")
except ZeroDivisionError:
    f2_ave=0
    print(f"F2 average:{f2_ave}")

try:
    f3_ave=sum(f3_list)/len(f3_list)
    print(f"F3 average:{f3_ave}")
except ZeroDivisionError:
    f3_ave=0
    print(f"F3 average:{f3_ave}")