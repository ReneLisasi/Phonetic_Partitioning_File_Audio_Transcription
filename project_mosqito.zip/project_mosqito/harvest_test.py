import parselmouth
from parselmouth import praat
import file_input

rel_path = file_input.rel_path
voice_filename = file_input.voice_filename

# Print the file name without the extension
print(f"------\nBegin harvest for ~ {voice_filename}\n------")

sound = parselmouth.Sound(rel_path)
f3_list = []

# Define a time window for consonants (adjust as needed)
start_time = 0  # Start time in seconds
end_time = 0.3    # End time in seconds

# Extract spectrogram for the time window
spectrogram = praat.call(sound, "To Spectrogram", 0.01, 0.025, 5000, 0.0025, 1.3, 1.6, "Gaussian", 0.025, 50)
intensity = praat.call(spectrogram, "To Intensity (jitter local)", 75, 0.0001, 0.02, 1.3, 1.6)

# Analyze F3 within the time window
for t in range(int(start_time * 1000), int(end_time * 1000)):
    f3 = praat.call(spectrogram, "Get value in absolute amplitude", 3, t / 1000)
    f3_list.append(f3)

print(f"F3 for the specified time window: {f3_list}")
