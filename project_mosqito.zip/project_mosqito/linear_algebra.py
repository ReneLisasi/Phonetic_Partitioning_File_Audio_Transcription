#Class focused on matrix manipulation
from math import sqrt

def cosine_similarity(input_vector, comparitive_vector):
    numerator=0
    input_magnitude=0
    comparitive_magnitude=0
    for index in range(len(input_vector)):
        numerator+=(input_vector[index]*comparitive_vector[index])
        input_magnitude+=(input_vector[index]**2)
        comparitive_magnitude+=(comparitive_vector[index]**2)
    similarity=numerator/(sqrt(input_magnitude)*sqrt(comparitive_magnitude))
    cosine_distance=1-similarity
    # print(f'Smiliarity: {similarity}, Cosine Distance: {cosine_distance}')
    # return similarity,cosine_distance
    return cosine_distance
