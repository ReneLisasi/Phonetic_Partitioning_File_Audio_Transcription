from pydub import AudioSegment
import os
import subprocess

def convert_m4a(file):
    # Load the M4A file
    m4a_file = file
    audio = AudioSegment.from_file(m4a_file, format="m4a")

    # Get the base filename without extension
    file_name_without_extension = os.path.splitext(m4a_file)[0]

    # Create the output WAV file with the same name as the M4A file
    wav_file = f"{file_name_without_extension}.wav"
    audio.export(wav_file, format="wav")

    print(f"Conversion complete! {m4a_file} converted to {wav_file}")


def convert_mp3(file):
    # Load the MP3 file
    mp3_file = file
    audio = AudioSegment.from_file(mp3_file, format="mp3")

    # Get the base filename without extension
    file_name_without_extension = os.path.splitext(mp3_file)[0]

    # Create the output WAV file with the same name as the MP3 file
    wav_file = f"{file_name_without_extension}.wav"
    audio.export(wav_file, format="wav")

    print(f"Conversion complete! {mp3_file} converted to {wav_file}")

def convert_mp3_dir(input_dir):
    # List all files in the input directory
    for root, _, files in os.walk(input_dir):
        for file in files:
            if file.lower().endswith(".mp3"):
                mp3_file = os.path.join(root, file)
                audio = AudioSegment.from_file(mp3_file, format="mp3")

                # Get the base filename without extension
                file_name_without_extension = os.path.splitext(file)[0]

                # Create the output WAV file in the same directory
                wav_file = os.path.join(root, f"{file_name_without_extension}.wav")
                audio.export(wav_file, format="wav")

                print(f"Conversion complete! {mp3_file} converted to {wav_file}")

def convert_mp3_to_m4a_dir(input_dir):
    # List all files in the input directory
    for root, _, files in os.walk(input_dir):
        for file in files:
            if file.lower().endswith(".mp3"):
                mp3_file = os.path.join(root, file)
                m4a_file = os.path.join(root, os.path.splitext(file)[0] + ".m4a")

                # Use FFmpeg to convert MP3 to M4A
                cmd = [
                    'ffmpeg',
                    '-i', mp3_file,
                    '-c:a', 'aac',
                    '-strict', 'experimental',
                    '-q:a', '2',
                    m4a_file
                ]

                subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

                print(f"Conversion complete! {mp3_file} converted to {m4a_file}")

# # Example usage:
# convert_mp3_to_m4a_dir("res/unorganized_data")

# convert_mp3_dir("res/other_data/wikipedia")

convert_m4a('res/test_data/words/shame2t.m4a')